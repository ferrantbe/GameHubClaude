package be.ephec.gamehub.modele;

import java.time.LocalDateTime;

/**
 * G.2, G.4, G.7, G.12 — CORRIGE.
 *
 * Cette classe a grandi par couches, et chaque couche a son exercice :
 *
 *   G.2   les deux joueurs et le toString ;
 *   G.4   les dates de debut et de fin ;
 *   G.7   le type de jeu et le resultat ;
 *   G.12  la liste d'observateurs et les notifications.
 *
 * DEUX POINTS MERITENT L'ATTENTION.
 *
 * La date de debut est prise dans le CONSTRUCTEUR, celle de fin dans
 * terminer. Une partie commence donc au moment ou l'objet existe : il n'y
 * a aucun instant ou une Partie serait sans date de debut.
 *
 * Les methodes de notification sont PRIVEES. Personne d'autre que la
 * partie n'a le droit de declarer qu'un coup a ete joue.
 *
 * UNE REMARQUE SUR L'ENONCE G.12. Il demande d'appeler notifierDebut
 * dans le constructeur. Or les observateurs s'ajoutent APRES la
 * construction : au moment ou notifierDebut s'execute, la liste est vide
 * et personne n'est prevenu.
 *
 * Le code ci-dessous suit l'enonce a la lettre, et l'appel est donc sans
 * effet. Trois facons de le corriger, selon ce qu'on prefere :
 *
 *   passer les observateurs au constructeur ;
 *   prevenir un observateur au moment ou il s'abonne ;
 *   ou deplacer le debut dans une methode demarrer(), appelee par le jeu.
 *
 * C'est exactement le genre de decalage qu'on ne voit qu'en executant.
 */
public class Partie {

    private final Joueur joueur1;
    private final Joueur joueur2;
    private final LocalDateTime dateHeureDebut;

    private LocalDateTime dateHeureFin;

    public Partie(Joueur joueur1, Joueur joueur2) {
        this.joueur1 = joueur1;
        this.joueur2 = joueur2;
        this.dateHeureDebut = LocalDateTime.now();
    }

    /**
     * Appelee par le jeu a chaque coup. C'est le seul point d'entree
     * public des notifications : le jeu signale, la partie previent.
     */

    /**
     * G.7 : c'est terminer qui recoit le resultat et l'enregistre.
     * G.8 : c'est aussi ici que le ResumePartie se fabrique, parce que
     * c'est le seul moment ou toutes ses donnees existent.
     */
    public void terminer() {
        this.dateHeureFin = LocalDateTime.now();
    }

    public Joueur getJoueur1() {
        return joueur1;
    }

    public Joueur getJoueur2() {
        return joueur2;
    }

    public LocalDateTime getDateHeureDebut() {
        return dateHeureDebut;
    }

    public LocalDateTime getDateHeureFin() {
        return dateHeureFin;
    }

    @Override
    public String toString() {
        return "Partie entre " + joueur1 + " et " + joueur2;
    }
}