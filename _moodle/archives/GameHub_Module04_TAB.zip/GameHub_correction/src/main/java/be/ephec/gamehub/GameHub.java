package be.ephec.gamehub;

import be.ephec.gamehub.modele.Joueur;
import be.ephec.gamehub.modele.Partie;

import java.util.Scanner;

/**
 * G.3, G.9 — CORRIGE, complete au fil des increments.
 *
 * CE QUE CETTE CLASSE NE CONNAIT PAS, et c'est le resultat de tout le fil
 * rouge : aucune classe concrete de jeu. Elle manipule un Jeu, demande a
 * la JeuFactory de le construire, et n'a jamais besoin de savoir lequel.
 *
 * Ajouter un jeu ne demande aucune ligne ici.
 *
 * AUCUNE FENETRE ICI. Le hub est une application console, et il le reste.
 * La fenetre du Nim (G.33) est une application a part, avec son propre
 * lanceur : l'ouvrir depuis ce menu demanderait de demarrer JavaFX a la
 * main, sur un autre fil d'execution.
 *
 * G.35 : le hub ne joue qu'une partie par lancement. C'est le journal,
 * ecrit dans un fichier, qui se souvient des precedentes.
 */
public class GameHub {

    public static void main(String[] args) {
        Scanner clavier = new Scanner(System.in);

        Joueur joueur1 = demanderJoueur(clavier, "premier");
        Joueur joueur2 = demanderJoueur(clavier, "second");

        // Le hub ne sait pas si ce jeu se configure : il demande.

        Partie partie = new Partie(joueur1, joueur2);

        System.out.println("\n" + partie);

        System.out.println("\n" + partie);
    }

    private static Joueur demanderJoueur(Scanner clavier, String rang) {
        System.out.print("Pseudo du " + rang + " joueur : ");
        String pseudo = clavier.nextLine().trim();
        System.out.print("Email du " + rang + " joueur : ");
        String email = clavier.nextLine().trim();
        return new Joueur(pseudo, email);
    }

    /**
     * Le menu se construit a partir de values() : ajouter un jeu au
     * catalogue le fait apparaitre ici sans qu'on touche a cette methode.
     * C'est la meme idee qu'en ENU.1.
     */
}