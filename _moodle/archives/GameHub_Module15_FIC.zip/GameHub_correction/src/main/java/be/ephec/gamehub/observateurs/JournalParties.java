package be.ephec.gamehub.observateurs;

import be.ephec.gamehub.modele.Partie;

/**
 * G.13 et G.35 — CORRIGE.
 *
 * Un observateur qui ecrit sur la console. Il ne sait rien du jeu en
 * cours, ne le modifie pas, et pourrait etre remplace par un observateur
 * qui ecrit dans un fichier sans qu'une ligne de Partie change.
 *
 * Le compteur de coups est un etat propre a l'observateur. Il montre
 * qu'un observateur peut avoir sa propre memoire, ce qu'un simple
 * affichage ne laisserait pas deviner.
 *
 * G.35 — LE JOURNAL SE SOUVIENT. Le hub ne joue qu'une partie par
 * lancement : sans fichier, aucune partie ne survit a la suivante. Chaque
 * partie terminee s'ajoute donc, sur une ligne, a la fin d'un fichier
 * texte, et historique() relit ce fichier au lancement suivant.
 *
 * Le format est un choix, et il se discute : quatre champs separes par un
 * point-virgule, dans l'ordre type, gagnant, debut, fin. Le type est ecrit
 * par son nom de constante, NIM, et non par son libelle, « Jeu de Nim » :
 * c'est le nom que valueOf sait relire.
 *
 * Une erreur d'ecriture ne doit pas faire perdre la partie qu'on vient de
 * jouer : elle est signalee, et le hub continue. Voir CC-ERR.2.
 */
public class JournalParties implements ObservateurPartie {

    private int coups = 0;

    @Override
    public void onDebut(Partie partie) {
        coups = 0;
        System.out.println("[journal] debut — " + partie);
    }

    @Override
    public void onCoup(Partie partie) {
        coups++;
        System.out.println("[journal] coup " + coups);
    }

    @Override
    public void onFin(Partie partie) {
        System.out.println("[journal] fin apres " + coups + " coup(s) — " + partie);
    }

}