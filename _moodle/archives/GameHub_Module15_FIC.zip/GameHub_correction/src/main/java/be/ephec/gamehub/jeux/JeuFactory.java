package be.ephec.gamehub.jeux;

import be.ephec.gamehub.jeux.bataille.JeuBatailleV1;
import be.ephec.gamehub.jeux.morpion.JeuMorpion;
import be.ephec.gamehub.jeux.puissance4.JeuPuissance4;
import be.ephec.gamehub.jeux.nim.JeuNim;
import be.ephec.gamehub.jeux.nim.ReglesNim;
import be.ephec.gamehub.modele.TypeJeu;

import java.util.Map;
import java.util.function.Supplier;

/**
 * ATTENTION — PAS D'ENONCE NUMEROTE. Decrite dans le deck 04, slide 26.
 *
 * Le patron Fabrique. Son interet tient en une phrase : GameHub ne
 * connait que le type Jeu, et delegue la construction. Aucun import de
 * classe concrete de jeu n'apparait dans GameHub.
 *
 * C'est le seul endroit du programme qui connaisse toutes les classes de
 * jeux. Ajouter un jeu, c'est ajouter une valeur a TypeJeu et un cas ici.
 */
public class JeuFactory {

    /** Le nombre d'allumettes d'une partie de Nim, par defaut. */
    private static final int ALLUMETTES_NIM = 13;

    // G.32 — la facon de fabriquer chaque jeu, rangee par type. Une valeur
    // n'est pas un jeu, c'est de quoi en fabriquer un neuf a chaque appel.
    private static final Map<TypeJeu, Supplier<Jeu>> CATALOGUE = Map.of(
            TypeJeu.NIM, () -> new JeuNim(ALLUMETTES_NIM, new ReglesNim()),
            TypeJeu.BATAILLE, JeuBatailleV1::new,
            TypeJeu.DEVINE_LE_NOMBRE, JeuDevineLeNombre::new,
            TypeJeu.MORPION, JeuMorpion::new,
            TypeJeu.PUISSANCE4, JeuPuissance4::new);

    public Jeu creer(TypeJeu type) {
        Supplier<Jeu> fabrication = CATALOGUE.get(type);
        if (fabrication == null) {
            throw new UnsupportedOperationException(type + " n'est pas encore implemente");
        }
        return fabrication.get();
    }
}