# GameHub_correction - module POO

Ce projet contient aucun code : c'est le projet de départ, vide. Ce module : G.1 à G.3.

## Deux projets GameHub

Vous gérez deux projets, côte à côte dans le même dossier :

    GameHub              le vôtre : vous y écrivez les incréments
    GameHub_correction   celui-ci : la correction officielle

Au début de chaque module, une nouvelle archive remplace GameHub_correction
par la correction à jour. Décompressez-la dans le dossier qui contient vos deux
projets : elle ne touche jamais à votre GameHub.

**Au premier module (POO)**, copiez ce dossier une fois sous le nom GameHub :
ce sera votre projet. Ensuite, n'y recopiez rien sans y réfléchir.

## Ouvrir les deux projets

Ouvrez chacun dans sa propre fenêtre IntelliJ (File, Open, son pom.xml).
Ne les ouvrez pas comme deux modules d'un même projet : ils contiennent les
mêmes classes, et IntelliJ les mélangerait.

## Comparer votre code à la correction

Dans votre projet, clic droit sur un fichier, puis Compare With…, et
choisissez le même fichier dans GameHub_correction : les différences
s'affichent côte à côte. C'est la meilleure façon de lire une correction.

## Recopier une classe

Si vous êtes bloqué, vous pouvez recopier une classe de la correction dans
votre projet. Attention : si vos choix diffèrent de ceux de la correction, la
classe recopiée peut demander d'autres classes, ou d'autres méthodes, que
votre projet n'a pas. Recopier une classe, c'est parfois aussi recopier ce
dont elle dépend.

## Votre projet sous Git

Votre GameHub gagne à être sous Git : commitez à la fin de chaque incrément,
et vous pourrez toujours revenir en arrière. Voir _documents/Git_pour_GameHub.docx.

Les énoncés de tous les incréments sont dans _documents/GameHub_enonces.docx.
